﻿#include "Render.h"

float full_time = 0.0f;
double delta_global = 0.0;

Texture texWall;
Texture texFloor;
Texture texBackWall;
Texture texDoorClosed;
Texture texDoorOpen;
Texture texFan;
Texture texAnimatronicHint;
Texture texStaticNoise;
Texture texCam1;
Texture texCam2;
Texture texCam3;
Texture texScreamer;
Texture texAnimatronicCorridor;
Texture texDoorLitEmpty;
Texture texDoorLitAnimatronic;

ObjModel fanBase;
ObjModel fanBlade;

Shader phongTexShader;
Shader cameraNoiseShader;

bool doorOpen = false;
float cameraYaw = 0.0f;
float animatronicTimer = 0.0f;

AnimatronicState animState = STATE_STAGE;
float stateTimer = 0.0f;
bool gameOver = false;
bool lightOn = false;
bool monitorOpen = false;
int activeCam = 1;
float camBlendFactor = 0.0f;
int prevCam = 1;
bool camSwitching = false;
float camSwitchTimer = 0.0f;

float mouseX = 0.0f;
int screenWidth = 800;

void drawQuad(float x1, float y1, float z1, float x2, float y2, float z2,
            float x3, float y3, float z3, float x4, float y4, float z4,
            float nx, float ny, float nz)
{
    glBegin(GL_QUADS);
    glNormal3f(nx, ny, nz);
    glTexCoord2f(0.0f, 0.0f); glVertex3f(x1, y1, z1);
    glTexCoord2f(1.0f, 0.0f); glVertex3f(x2, y2, z2);
    glTexCoord2f(1.0f, 1.0f); glVertex3f(x3, y3, z3);
    glTexCoord2f(0.0f, 1.0f); glVertex3f(x4, y4, z4);
    glEnd();
}

void drawRoom(float view_matrix[16])
{
    phongTexShader.UseShader();

    float lp[4] = { 0.0f, 3.5f, 0.0f, 1.0f };
    float lp_v[4];
    MatrixMultiply<float, 1, 4, 4, 4>(lp, view_matrix, lp_v);

    int loc = glGetUniformLocationARB(phongTexShader.program, "light_pos_v");
    glUniform3fvARB(loc, 1, lp_v);
    loc = glGetUniformLocationARB(phongTexShader.program, "Ia");
    glUniform3fARB(loc, 0.3f, 0.3f, 0.3f);
    loc = glGetUniformLocationARB(phongTexShader.program, "Id");
    glUniform3fARB(loc, 0.8f, 0.8f, 0.7f);
    loc = glGetUniformLocationARB(phongTexShader.program, "Is");
    glUniform3fARB(loc, 0.5f, 0.5f, 0.5f);
    loc = glGetUniformLocationARB(phongTexShader.program, "ma");
    glUniform3fARB(loc, 0.2f, 0.2f, 0.2f);
    loc = glGetUniformLocationARB(phongTexShader.program, "md");
    glUniform3fARB(loc, 0.8f, 0.8f, 0.8f);
    loc = glGetUniformLocationARB(phongTexShader.program, "ms");
    glUniform3fARB(loc, 0.3f, 0.3f, 0.3f);
    loc = glGetUniformLocationARB(phongTexShader.program, "sh");
    glUniform1fARB(loc, 32.0f);
    loc = glGetUniformLocationARB(phongTexShader.program, "tex");
    glUniform1iARB(loc, 0);

    texWall.Bind();
    drawQuad(-2.0f, 0.0f, -2.0f, -2.0f, 0.0f, 2.0f, -2.0f, 4.0f, 2.0f, -2.0f, 4.0f, -2.0f, 1.0f, 0.0f, 0.0f);
    drawQuad(2.0f, 0.0f, 2.0f, 2.0f, 0.0f, -2.0f, 2.0f, 4.0f, -2.0f, 2.0f, 4.0f, 2.0f, -1.0f, 0.0f, 0.0f);

    texFloor.Bind();
    drawQuad(-2.0f, 0.0f, 2.0f, 2.0f, 0.0f, 2.0f, 2.0f, 0.0f, -2.0f, -2.0f, 0.0f, -2.0f, 0.0f, 1.0f, 0.0f);

    glBindTexture(GL_TEXTURE_2D, 0);
    drawQuad(-2.0f, 4.0f, -2.0f, 2.0f, 4.0f, -2.0f, 2.0f, 4.0f, 2.0f, -2.0f, 4.0f, 2.0f, 0.0f, -1.0f, 0.0f);

    if (animState == STATE_CORRIDOR || animState == STATE_ATTACK)
    {
        texAnimatronicHint.Bind();
    }
    else
    {
        texBackWall.Bind();
    }

    loc = glGetUniformLocationARB(phongTexShader.program, "tex");
    glUniform1iARB(loc, 0);
    drawQuad(-2.0f, 0.0f, -2.0f, 2.0f, 0.0f, -2.0f, 2.0f, 4.0f, -2.0f, -2.0f, 4.0f, -2.0f, 0.0f, 0.0f, 1.0f);

    Shader::DontUseShaders();
}

void drawDoor(float view_matrix[16])
{
    phongTexShader.UseShader();

    float lp[4] = { 0.0f, 3.5f, 0.0f, 1.0f };
    float lp_v[4];
    MatrixMultiply<float, 1, 4, 4, 4>(lp, view_matrix, lp_v);

    int loc = glGetUniformLocationARB(phongTexShader.program, "light_pos_v");
    glUniform3fvARB(loc, 1, lp_v);
    loc = glGetUniformLocationARB(phongTexShader.program, "Ia");
    glUniform3fARB(loc, 0.3f, 0.3f, 0.3f);
    loc = glGetUniformLocationARB(phongTexShader.program, "Id");
    glUniform3fARB(loc, 0.8f, 0.8f, 0.7f);
    loc = glGetUniformLocationARB(phongTexShader.program, "Is");
    glUniform3fARB(loc, 0.5f, 0.5f, 0.5f);
    loc = glGetUniformLocationARB(phongTexShader.program, "ma");
    glUniform3fARB(loc, 0.2f, 0.2f, 0.2f);
    loc = glGetUniformLocationARB(phongTexShader.program, "md");
    glUniform3fARB(loc, 0.8f, 0.8f, 0.8f);
    loc = glGetUniformLocationARB(phongTexShader.program, "ms");
    glUniform3fARB(loc, 0.3f, 0.3f, 0.3f);
    loc = glGetUniformLocationARB(phongTexShader.program, "sh");
    glUniform1fARB(loc, 32.0f);
    loc = glGetUniformLocationARB(phongTexShader.program, "tex");
    glUniform1iARB(loc, 0);

    if (lightOn && animState == STATE_CORRIDOR)
    {
        texDoorLitAnimatronic.Bind();
    }
    else if (lightOn && animState == STATE_STAGE)
    {
        texDoorLitEmpty.Bind();
    }
    else if (doorOpen)
    {
        texDoorOpen.Bind();
    }
    else
    {
        texDoorClosed.Bind();
    }

    loc = glGetUniformLocationARB(phongTexShader.program, "tex");
    glUniform1iARB(loc, 0);
    drawQuad(2.0f, 0.0f, -0.75f, 2.0f, 0.0f, 0.75f, 2.0f, 3.0f, 0.75f, 2.0f, 3.0f, -0.75f, -1.0f, 0.0f, 0.0f);

    Shader::DontUseShaders();
}

void drawTable(float view_matrix[16])
{
    phongTexShader.UseShader();

    float lp[4] = { 0.0f, 3.5f, 0.0f, 1.0f };
    float lp_v[4];
    MatrixMultiply<float, 1, 4, 4, 4>(lp, view_matrix, lp_v);

    int loc = glGetUniformLocationARB(phongTexShader.program, "light_pos_v");
    glUniform3fvARB(loc, 1, lp_v);
    loc = glGetUniformLocationARB(phongTexShader.program, "Ia");
    glUniform3fARB(loc, 0.3f, 0.3f, 0.3f);
    loc = glGetUniformLocationARB(phongTexShader.program, "Id");
    glUniform3fARB(loc, 0.8f, 0.8f, 0.7f);
    loc = glGetUniformLocationARB(phongTexShader.program, "Is");
    glUniform3fARB(loc, 0.5f, 0.5f, 0.5f);
    loc = glGetUniformLocationARB(phongTexShader.program, "ma");
    glUniform3fARB(loc, 0.05f, 0.05f, 0.05f);
    loc = glGetUniformLocationARB(phongTexShader.program, "md");
    glUniform3fARB(loc, 0.1f, 0.1f, 0.1f);
    loc = glGetUniformLocationARB(phongTexShader.program, "ms");
    glUniform3fARB(loc, 0.2f, 0.2f, 0.2f);
    loc = glGetUniformLocationARB(phongTexShader.program, "sh");
    glUniform1fARB(loc, 64.0f);
    loc = glGetUniformLocationARB(phongTexShader.program, "tex");
    glUniform1iARB(loc, 0);

    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, 0);

    float w = 1.2f, h = 0.05f, d = 0.6f;
    float x = 0.0f, y = 0.8f, z = 0.5f;

    glBegin(GL_QUADS);
    glNormal3f(0.0f, 1.0f, 0.0f);
    glTexCoord2f(0.0f, 0.0f); glVertex3f(x - w, y + h, z - d);
    glTexCoord2f(1.0f, 0.0f); glVertex3f(x + w, y + h, z - d);
    glTexCoord2f(1.0f, 1.0f); glVertex3f(x + w, y + h, z + d);
    glTexCoord2f(0.0f, 1.0f); glVertex3f(x - w, y + h, z + d);

    glNormal3f(0.0f, -1.0f, 0.0f);
    glTexCoord2f(0.0f, 0.0f); glVertex3f(x - w, y - h, z + d);
    glTexCoord2f(1.0f, 0.0f); glVertex3f(x + w, y - h, z + d);
    glTexCoord2f(1.0f, 1.0f); glVertex3f(x + w, y - h, z - d);
    glTexCoord2f(0.0f, 1.0f); glVertex3f(x - w, y - h, z - d);

    glNormal3f(0.0f, 0.0f, 1.0f);
    glTexCoord2f(0.0f, 0.0f); glVertex3f(x - w, y + h, z + d);
    glTexCoord2f(1.0f, 0.0f); glVertex3f(x + w, y + h, z + d);
    glTexCoord2f(1.0f, 1.0f); glVertex3f(x + w, y - h, z + d);
    glTexCoord2f(0.0f, 1.0f); glVertex3f(x - w, y - h, z + d);

    glNormal3f(0.0f, 0.0f, -1.0f);
    glTexCoord2f(0.0f, 0.0f); glVertex3f(x - w, y - h, z - d);
    glTexCoord2f(1.0f, 0.0f); glVertex3f(x + w, y - h, z - d);
    glTexCoord2f(1.0f, 1.0f); glVertex3f(x + w, y + h, z - d);
    glTexCoord2f(0.0f, 1.0f); glVertex3f(x - w, y + h, z - d);

    glNormal3f(1.0f, 0.0f, 0.0f);
    glTexCoord2f(0.0f, 0.0f); glVertex3f(x + w, y + h, z + d);
    glTexCoord2f(1.0f, 0.0f); glVertex3f(x + w, y + h, z - d);
    glTexCoord2f(1.0f, 1.0f); glVertex3f(x + w, y - h, z - d);
    glTexCoord2f(0.0f, 1.0f); glVertex3f(x + w, y - h, z + d);

    glNormal3f(-1.0f, 0.0f, 0.0f);
    glTexCoord2f(0.0f, 0.0f); glVertex3f(x - w, y + h, z - d);
    glTexCoord2f(1.0f, 0.0f); glVertex3f(x - w, y + h, z + d);
    glTexCoord2f(1.0f, 1.0f); glVertex3f(x - w, y - h, z + d);
    glTexCoord2f(0.0f, 1.0f); glVertex3f(x - w, y - h, z - d);
    glEnd();

    Shader::DontUseShaders();
}

void drawFan(float view_matrix[16])
{
    phongTexShader.UseShader();

    float lp[4] = { 0.0f, 3.5f, 0.0f, 1.0f };
    float lp_v[4];
    MatrixMultiply<float, 1, 4, 4, 4>(lp, view_matrix, lp_v);

    int loc = glGetUniformLocationARB(phongTexShader.program, "light_pos_v");
    glUniform3fvARB(loc, 1, lp_v);
    loc = glGetUniformLocationARB(phongTexShader.program, "Ia");
    glUniform3fARB(loc, 0.3f, 0.3f, 0.3f);
    loc = glGetUniformLocationARB(phongTexShader.program, "Id");
    glUniform3fARB(loc, 0.8f, 0.8f, 0.7f);
    loc = glGetUniformLocationARB(phongTexShader.program, "Is");
    glUniform3fARB(loc, 0.5f, 0.5f, 0.5f);
    loc = glGetUniformLocationARB(phongTexShader.program, "ma");
    glUniform3fARB(loc, 0.15f, 0.15f, 0.15f);
    loc = glGetUniformLocationARB(phongTexShader.program, "md");
    glUniform3fARB(loc, 0.6f, 0.6f, 0.6f);
    loc = glGetUniformLocationARB(phongTexShader.program, "ms");
    glUniform3fARB(loc, 0.4f, 0.4f, 0.4f);
    loc = glGetUniformLocationARB(phongTexShader.program, "sh");
    glUniform1fARB(loc, 48.0f);
    loc = glGetUniformLocationARB(phongTexShader.program, "tex");
    glUniform1iARB(loc, 0);

    texFan.Bind();

    glPushMatrix();
    glTranslated(0.0f, 1.4f, -1.2f);
    glScaled(0.5f, 0.5f, 0.5f);

    fanBase.Draw();

    glPushMatrix();
    glTranslated(0.0f, 0.6f, 0.0f);
    glRotated(full_time * 180.0, 0.0, 1.0, 0.0);
    fanBlade.Draw();
    glPopMatrix();

    glPopMatrix();

    Shader::DontUseShaders();
}

void drawMonitor()
{
    if (!monitorOpen) return;

    glDisable(GL_DEPTH_TEST);
    glDisable(GL_LIGHTING);

    cameraNoiseShader.UseShader();

    glActiveTexture(GL_TEXTURE0);
    if (activeCam == 1) texCam1.Bind();
    else if (activeCam == 2) texCam2.Bind();
    else texCam3.Bind();

    glActiveTexture(GL_TEXTURE1);
    texStaticNoise.Bind();

    int loc = glGetUniformLocationARB(cameraNoiseShader.program, "texStatic");
    glUniform1iARB(loc, 0);
    loc = glGetUniformLocationARB(cameraNoiseShader.program, "texCamera");
    glUniform1iARB(loc, 1);
    loc = glGetUniformLocationARB(cameraNoiseShader.program, "u_time");
    glUniform1fARB(loc, full_time);

    glMatrixMode(GL_PROJECTION);
    glPushMatrix();
    glLoadIdentity();
    gluOrtho2D(0, 1, 0, 1);

    glMatrixMode(GL_MODELVIEW);
    glPushMatrix();
    glLoadIdentity();

    glBegin(GL_QUADS);
    glTexCoord2f(0.0f, 0.0f); glVertex2f(0.1f, 0.1f);
    glTexCoord2f(1.0f, 0.0f); glVertex2f(0.9f, 0.1f);
    glTexCoord2f(1.0f, 1.0f); glVertex2f(0.9f, 0.9f);
    glTexCoord2f(0.0f, 1.0f); glVertex2f(0.1f, 0.9f);
    glEnd();

    glPopMatrix();
    glMatrixMode(GL_PROJECTION);
    glPopMatrix();
    glMatrixMode(GL_MODELVIEW);

    Shader::DontUseShaders();

    glActiveTexture(GL_TEXTURE0);
    glEnable(GL_DEPTH_TEST);
    glEnable(GL_LIGHTING);
}

void drawScreamer()
{
    if (animState != STATE_ATTACK) return;

    glDisable(GL_DEPTH_TEST);
    glDisable(GL_LIGHTING);

    glMatrixMode(GL_PROJECTION);
    glPushMatrix();
    glLoadIdentity();
    gluOrtho2D(0, 1, 0, 1);

    glMatrixMode(GL_MODELVIEW);
    glPushMatrix();
    glLoadIdentity();

    glEnable(GL_TEXTURE_2D);
    texScreamer.Bind();

    glBegin(GL_QUADS);
    glTexCoord2f(0.0f, 0.0f); glVertex2f(0.0f, 0.0f);
    glTexCoord2f(1.0f, 0.0f); glVertex2f(1.0f, 0.0f);
    glTexCoord2f(1.0f, 1.0f); glVertex2f(1.0f, 1.0f);
    glTexCoord2f(0.0f, 1.0f); glVertex2f(0.0f, 1.0f);
    glEnd();

    glPopMatrix();
    glMatrixMode(GL_PROJECTION);
    glPopMatrix();
    glMatrixMode(GL_MODELVIEW);

    glEnable(GL_DEPTH_TEST);
    glEnable(GL_LIGHTING);
}

void resetGame()
{
    animState = STATE_STAGE;
    stateTimer = 0.0f;
    doorOpen = false;
    gameOver = false;
    lightOn = false;
    monitorOpen = false;
    activeCam = 1;
    camBlendFactor = 0.0f;
    prevCam = 1;
    camSwitching = false;
    camSwitchTimer = 0.0f;
    cameraYaw = 0.0f;
}

void updateAnimatronic(float dt)
{
    if (gameOver) return;

    stateTimer += dt;

    switch (animState)
    {
    case STATE_STAGE:
        if (stateTimer >= 8.0f)
        {
            animState = STATE_CORRIDOR;
            stateTimer = 0.0f;
        }
        break;

    case STATE_CORRIDOR:
        if (doorOpen)
        {
            animState = STATE_ATTACK;
            stateTimer = 0.0f;
            gameOver = true;
        }
        else if (stateTimer >= 3.0f)
        {
            animState = STATE_STAGE;
            stateTimer = 0.0f;
        }
        break;

    case STATE_ATTACK:
        if (stateTimer >= 2.0f)
        {
            resetGame();
        }
        break;
    }
}

void onKeyPress(OpenGL* sender, KeyEventArg arg)
{
    auto key = LOWORD(MapVirtualKeyA(arg.key, MAPVK_VK_TO_CHAR));
    switch (key)
    {
    case 'E':
    case 'e':
        if (!gameOver && !monitorOpen) doorOpen = !doorOpen;
        break;
    case 'F':
    case 'f':
        if (!gameOver && !monitorOpen) lightOn = !lightOn;
        break;
    case '1':
        if (monitorOpen) { prevCam = activeCam; activeCam = 1; camSwitching = true; camSwitchTimer = 0.0f; }
        break;
    case '2':
        if (monitorOpen) { prevCam = activeCam; activeCam = 2; camSwitching = true; camSwitchTimer = 0.0f; }
        break;
    case '3':
        if (monitorOpen) { prevCam = activeCam; activeCam = 3; camSwitching = true; camSwitchTimer = 0.0f; }
        break;
    }

    if (arg.key == VK_SPACE || arg.key == VK_TAB)
    {
        if (fabs(cameraYaw) < 5.0f && !gameOver)
        {
            monitorOpen = !monitorOpen;
        }
    }
}

void onMouseMove(OpenGL* sender, MouseEventArg arg)
{
    mouseX = static_cast<float>(arg.x);

    if (monitorOpen) return;

    if (mouseX < screenWidth * 0.25f)
    {
        cameraYaw += 0.5f;
        if (cameraYaw > 45.0f) cameraYaw = 45.0f;
    }
    else if (mouseX > screenWidth * 0.75f)
    {
        cameraYaw -= 0.5f;
        if (cameraYaw < -45.0f) cameraYaw = -45.0f;
    }
}

void initRender()
{
    texWall.LoadTexture("textures/wall.png");
    texFloor.LoadTexture("textures/floor.png");
    texBackWall.LoadTexture("textures/backwall.png");
    texDoorClosed.LoadTexture("textures/door_closed.png");
    texDoorOpen.LoadTexture("textures/door_open.png");
    texFan.LoadTexture("textures/fan.png");
    texAnimatronicHint.LoadTexture("textures/animatronic_hint.png");
    texStaticNoise.LoadTexture("textures/static_noise.png");
    texCam1.LoadTexture("textures/cam1.png");
    texCam2.LoadTexture("textures/cam2.png");
    texCam3.LoadTexture("textures/cam3.png");
    texScreamer.LoadTexture("textures/screamer.png");
    texAnimatronicCorridor.LoadTexture("textures/animatronic_corridor.png");
    texDoorLitEmpty.LoadTexture("textures/door_lit_empty.png");
    texDoorLitAnimatronic.LoadTexture("textures/door_lit_animatronic.png");

    fanBase.LoadModel("models/fan_base.obj_m");
    fanBlade.LoadModel("models/fan_blade.obj_m");

    phongTexShader.VshaderFileName = "shaders/v.vert";
    phongTexShader.FshaderFileName = "shaders/phong_tex.frag";
    phongTexShader.LoadShaderFromFile();
    phongTexShader.Compile();

    cameraNoiseShader.VshaderFileName = "shaders/v.vert";
    cameraNoiseShader.FshaderFileName = "shaders/camera_noise.frag";
    cameraNoiseShader.LoadShaderFromFile();
    cameraNoiseShader.Compile();

    gl.KeyDownEvent.reaction(onKeyPress);
    gl.MouseMovieEvent.reaction(onMouseMove);

    screenWidth = gl.getWidth();

    glEnable(GL_DEPTH_TEST);
    glEnable(GL_LIGHTING);
    glEnable(GL_LIGHT0);

    float light_pos[] = { 0.0f, 3.5f, 0.0f, 1.0f };
    float light_amb[] = { 0.3f, 0.3f, 0.3f, 1.0f };
    float light_dif[] = { 0.8f, 0.8f, 0.7f, 1.0f };
    float light_spec[] = { 0.5f, 0.5f, 0.5f, 1.0f };

    glLightfv(GL_LIGHT0, GL_POSITION, light_pos);
    glLightfv(GL_LIGHT0, GL_AMBIENT, light_amb);
    glLightfv(GL_LIGHT0, GL_DIFFUSE, light_dif);
    glLightfv(GL_LIGHT0, GL_SPECULAR, light_spec);

    glEnable(GL_TEXTURE_2D);
}

void Render(double delta_time)
{
    delta_global = delta_time;
    full_time += static_cast<float>(delta_time);

    float dt = static_cast<float>(delta_time);
    updateAnimatronic(dt);

    if (camSwitching)
    {
        camSwitchTimer += dt;
        camBlendFactor = camSwitchTimer / 0.4f;
        if (camBlendFactor >= 1.0f)
        {
            camBlendFactor = 1.0f;
            camSwitching = false;
        }
    }

    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
    gluLookAt(0.0, 1.5, 0.0,
        0.0, 1.5, -1.0,
        0.0, 1.0, 0.0);

    glRotated(-cameraYaw, 0.0, 1.0, 0.0);

    float view_matrix[16];
    glGetFloatv(GL_MODELVIEW_MATRIX, view_matrix);

    drawRoom(view_matrix);
    drawDoor(view_matrix);
    drawTable(view_matrix);
    drawFan(view_matrix);

    drawMonitor();
    drawScreamer();
}
